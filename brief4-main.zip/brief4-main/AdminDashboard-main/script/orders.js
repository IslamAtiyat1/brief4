const Orders = [
    {
        productName: 'Flodable Mini Dorne',
        productNumber: '5863',
        paymentStatus: 'Due',
        shipping: 'Pending'

    },
    {
        productName: 'Larvander KF102 Dorne',
        productNumber: '5741',
        paymentStatus: 'Refunded',
        shipping: 'Declined'

    },
    {
        productName: 'Roko F11 Pro Dorne',
        productNumber: '1458',
        paymentStatus: 'Due',
        shipping: 'Pending'

    },
    {
        productName: 'Dorne with Camera Dorne',
        productNumber: '3546',
        paymentStatus: 'Paid',
        shipping: 'Delivered'

    },{
        productName:'GPS 4K Dorne',
        productNumber:'3500',
        paymentStatus:'Paid',
        shipping:'Delivered'
    
    }
]