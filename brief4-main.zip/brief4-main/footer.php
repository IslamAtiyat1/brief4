<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>footer</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <style>
        footer {
	background-color: #333;
	color: #fff;
	padding: 20px;
	text-align: center;
}
    </style>
</head>
<body>
<footer>
		<p>&copy; 2023 Flower Store. All Rights Reserved.</p>
	</footer>
</body>
</html>